const {
  default: makeWASocket,
  useMultiFileAuthState,
  makeCacheableSignalKeyStore,
  fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys');
const fs = require('fs');
const qrcode = require('qrcode-terminal');
const { manejarMensajes } = require('./messageHandler');
const { manejarBienvenidaDespedida } = require('./comandos/welcome'); // ✅ llamado correcto

// Logger simulado (evita errores como logger.trace / logger.child)
const fakeLogger = {
  info: () => {},
  warn: () => {},
  error: () => {},
  debug: () => {},
  trace: () => {},
  child: () => fakeLogger
};

async function iniciarBot() {
  const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, fakeLogger),
    },
    logger: fakeLogger,
    browser: ['Ubuntu', 'Chrome', '22.04'],
  });

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      qrcode.generate(qr, { small: true });
      console.log('[QR] Escaneá este código QR con tu WhatsApp 📱');
    }

    if (connection === 'open') {
      console.log('✅ BOT CONECTADO CORRECTAMENTE A WHATSAPP.');
    }

    if (connection === 'close') {
      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== 401;
      console.log('❌ Conexión cerrada. Reconectando:', shouldReconnect);
      if (shouldReconnect) {
        iniciarBot();
      }
    }
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('messages.upsert', async (mensaje) => {
    try {
      await manejarMensajes(mensaje, sock);
    } catch (err) {
      console.error('❌ Error al manejar mensaje:', err);
    }
  });

  sock.ev.on('group-participants.update', async (datos) => {
    try {
      await manejarBienvenidaDespedida(datos, sock);
    } catch (err) {
      console.error('❌ Error en bienvenida/despedida:', err);
    }
  });
}

iniciarBot();