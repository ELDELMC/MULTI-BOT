const fs = require('fs');
const rutaArchivo = './db_estado.json';

// Lee el archivo de estado, o lo crea si no existe
function leerEstado() {
  if (!fs.existsSync(rutaArchivo)) {
    fs.writeFileSync(rutaArchivo, JSON.stringify({}));
  }
  const datos = fs.readFileSync(rutaArchivo);
  return JSON.parse(datos);
}

// Guarda el estado actualizado en el archivo
function guardarEstado(estado) {
  fs.writeFileSync(rutaArchivo, JSON.stringify(estado, null, 2));
}

// Obtiene el valor de una clave (por ejemplo: 'modoSeguro', 'welcomeEnabled')
function obtener(clave) {
  const estado = leerEstado();
  return estado[clave] || {};
}

// Establece o actualiza el valor de una clave
function establecer(clave, valor) {
  const estado = leerEstado();
  estado[clave] = valor;
  guardarEstado(estado);
}

module.exports = {
  obtener,
  establecer
};