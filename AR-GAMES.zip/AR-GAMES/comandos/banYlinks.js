const linkRegex = /https?:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+/;

module.exports = async (sock, m, texto, remitente, infoGrupo) => {
  const chatId = m.key.remoteJid;
  const esAdmin = infoGrupo?.participants?.find(p => p.id === remitente)?.admin;
  const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
  const esBotAdmin = infoGrupo?.participants?.find(p => p.id === botNumber)?.admin;

  // 🔗 Eliminar mensajes con enlaces de grupos
  if (linkRegex.test(texto) && esBotAdmin) {
    await sock.sendMessage(chatId, {
      delete: {
        remoteJid: chatId,
        fromMe: false,
        id: m.key.id,
        participant: remitente,
      },
    });

    await sock.sendMessage(chatId, {
      text: 'ESTÁN PROHIBIDOS LOS ENLACES GUACHÍN 🤑',
    });
  }

  // 🔨 Comando ,,ban para expulsar
  if (texto === ',,ban' && esAdmin && esBotAdmin) {
    const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
    const mencionado = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const objetivo = mencionado || quoted;

    if (!objetivo) return sock.sendMessage(chatId, { text: 'Tenés que mencionar o responder al wacho.' });

    await sock.sendMessage(chatId, { text: 'TE HICISTE EL PIOLA GUACHÍN 🥵' });
    await sock.groupParticipantsUpdate(chatId, [objetivo], 'remove');
  }
};