const estado = require('../estado');

function contieneEnlaceDeGrupo(texto) {
  const regex = /chat\.whatsapp\.com\/[A-Za-z0-9]+/gi;
  return regex.test(texto);
}

async function esAdminGrupo(sock, jid, id) {
  const metadata = await sock.groupMetadata(jid);
  return metadata.participants.some(p => p.id === id && p.admin != null);
}

async function ejecutarModeracion({ sock, mensaje, texto, remitente }) {
  const jid = mensaje.key.remoteJid;

  // 1. Eliminar mensaje con enlace de grupo
  if (estado.banLinkEnabled) {
    const contenido = texto || '';
    if (contieneEnlaceDeGrupo(contenido)) {
      const esAdminBot = await esAdminGrupo(sock, jid, sock.user.id);
      if (esAdminBot) {
        // Eliminar mensaje del infractor
        await sock.sendMessage(jid, {
          delete: {
            remoteJid: jid,
            fromMe: false,
            id: mensaje.key.id,
            participant: mensaje.key.participant
          }
        });

        // Mensaje de advertencia
        await sock.sendMessage(jid, {
          text: 'ESTÁN PROHIBIDOS LOS ENLACES GUACHÍN 🤑'
        });
      }
    }
  }

  // 2. Comando ,,ban
  if (texto.startsWith(',,ban')) {
    const esAdminEmisor = await esAdminGrupo(sock, jid, remitente);
    const esAdminBot = await esAdminGrupo(sock, jid, sock.user.id);

    if (!esAdminEmisor || !esAdminBot) return;

    const citado = mensaje.message?.extendedTextMessage?.contextInfo?.participant;
    const mencionados = mensaje.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

    let objetivo = citado || mencionados[0];
    if (!objetivo) return;

    // Mensaje antes del ban
    await sock.sendMessage(jid, { text: 'TE HICISTE EL PIOLA GUACHÍN 🥵' });

    // Expulsar del grupo
    await sock.groupParticipantsUpdate(jid, [objetivo], 'remove');
  }
}

module.exports = { ejecutarModeracion };