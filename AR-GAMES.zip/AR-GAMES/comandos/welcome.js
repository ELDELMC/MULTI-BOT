// comandos/welcome.js
const estado = require('../estado');

const mensajesBienvenida = [
  "✨ Bienvenido al servidor *🇦🇷 ARGENGAMES.LAT 🇦🇷*, wachín 💙\nSoy Luli, tu admin favorita. Cualquier duda sobre comandos o survival, escribí `,,bot` 🛠️",
  "👋 ¡Hola genio! Llegaste a *ARGENGAMES.LAT* 🇦🇷\nTu admin te saluda 😄. ¿Te pinta una manito con el server? Mandá `,,bot`",
  "🎮 Bienvenido guachín, estás en casa: *ARGENGAMES.LAT* 🇦🇷\nSoy la que te puede ayudar con plugins, jobs o VIP. Usá `,,bot` 💬",
  "📦 ¡Nueva carga de TNT... digo... nuevo jugador! Bienvenido a *ARGENGAMES.LAT* 🇦🇷\nEscribí `,,bot` si tenés alguna duda técnica 🔧",
  "🚀 Te estaba esperando, wachín. Bienvenido a *ARGENGAMES.LAT* 🇦🇷\nSoy Luli, tu admin bot que te tira data de Minecraft, ¿todo piola?",
  "🧱 Hola hola, constructor. Bienvenido a *ARGENGAMES.LAT* 🇦🇷\nUsá `,,bot` si querés saber cómo progresar rápido en el survival 😏",
  "🌻 Llegaste al mejor server de todos, guacho.\n*ARGENGAMES.LAT* 🇦🇷 te recibe con los brazos abiertos y bloques listos.\nUsá `,,bot` si tenés preguntas 🧠",
  "🔥 Bienvenido al infierno... digo, al mejor survival del país: *ARGENGAMES.LAT* 🇦🇷\nSoy la bot-admin, cualquier duda escribí `,,bot` 😇",
  "🏰 Bienvenido caballero pixelado al reino *ARGENGAMES.LAT* 🇦🇷\nComandá tus aventuras y preguntame lo que necesites con `,,bot` 💫",
  "✨ Qué fachero que sos. Bienvenido a *ARGENGAMES.LAT* 🇦🇷\nCualquier cosita, preguntá con `,,bot`, estoy para ayudarte 👑"
];

function elegirMensajeBienvenida() {
  const index = Math.floor(Math.random() * mensajesBienvenida.length);
  return mensajesBienvenida[index];
}

async function sendWelcomeMessage(update, sock) {
  if (!estado.welcomeEnabled) return;

  const { action, participants, id: jid } = update;
  if (action !== 'add') return;

  for (const participante of participants) {
    const mensaje = elegirMensajeBienvenida();

    // Intentar obtener foto de perfil
    let fotoPerfil;
    try {
      fotoPerfil = await sock.profilePictureUrl(participante, 'image');
    } catch {
      fotoPerfil = null;
    }

    if (fotoPerfil) {
      // Enviar mensaje con imagen
      await sock.sendMessage(jid, {
        image: { url: fotoPerfil },
        caption: mensaje,
        mentions: [participante]
      });
    } else {
      // Enviar solo el texto
      await sock.sendMessage(jid, {
        text: mensaje,
        mentions: [participante]
      });
    }
  }
}

// Exportar con el nombre esperado por index.js
module.exports = { manejarBienvenidaDespedida: sendWelcomeMessage };