// comandos/admin.js
const estado = require('../estado');

function esAdminGrupo(infoGrupo, id) {
  return infoGrupo.participants.some(p => p.id === id && p.admin != null);
}

async function ejecutarAdministracion(sock, mensaje, texto, remitente, infoGrupo) {
  if (!estado.adminEnabled) return;

  const esAdminEmisor = esAdminGrupo(infoGrupo, remitente);
  const esAdminBot = esAdminGrupo(infoGrupo, sock.user.id);

  if (!esAdminEmisor || !esAdminBot) return;

  const citado = mensaje.message?.extendedTextMessage?.contextInfo?.participant;
  const mencionados = mensaje.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

  const objetivo = citado || mencionados[0];
  if (!objetivo) return;

  if (texto.startsWith(',,admin')) {
    await sock.groupParticipantsUpdate(infoGrupo.id, [objetivo], 'promote');
    await sock.sendMessage(infoGrupo.id, { text: 'HAS SIDO ASCENDIDO 🫡' });
  }

  if (texto.startsWith(',,noadmin')) {
    await sock.groupParticipantsUpdate(infoGrupo.id, [objetivo], 'demote');
    await sock.sendMessage(infoGrupo.id, { text: 'TE HAN DEGRADADO 📈' });
  }
}

module.exports = ejecutarAdministracion;