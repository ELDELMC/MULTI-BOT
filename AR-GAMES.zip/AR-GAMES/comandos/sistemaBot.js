// comandos/sistemaBot.js
const os = require('os');

module.exports = async (sock, m, texto, remitente, infoGrupo) => {
  const chatId = m.key.remoteJid;
  const comando = texto.trim().toLowerCase();

  const esAdmin = infoGrupo?.participants?.find(p => p.id === remitente)?.admin;
  if (!esAdmin) return;

  // Comando ,,P: Apagar
  if (comando === ',,p') {
    await sock.sendMessage(chatId, { text: 'Apagando el sistema wachín 😴' });
    process.exit(0);
  }

  // Comando ,,R: Reiniciar
  if (comando === ',,r') {
    await sock.sendMessage(chatId, { text: 'Reiniciando bot 🔁 Aguantame un segundo wachín...' });
    process.exit(1); // Algunos sistemas lo interpretan como reinicio si se corre en bucle
  }

  // Comando ,,ping: Estado del bot
  if (comando === ',,ping') {
    const tiempoInicio = Date.now();
    const usoMemoria = process.memoryUsage();
    const memoriaTotal = (os.totalmem() / 1024 / 1024).toFixed(2);
    const memoriaLibre = (os.freemem() / 1024 / 1024).toFixed(2);
    const usoRAM = (usoMemoria.rss / 1024 / 1024).toFixed(2);
    const velocidadCPU = os.cpus()[0].speed;
    const modeloCPU = os.cpus()[0].model;

    const tiempoFinal = Date.now();
    const ping = tiempoFinal - tiempoInicio;

    const textoEstado = `
Mí estado es el siguiente mí rey 👑
Bueeee no sé cómo me ves pero estoy re piola🥵
lista para eliminar a quien se nos atraviesa en nuestro grupo

\`\`\`
> Ping           : ${ping} ms
> RAM usada      : ${usoRAM} MB
> RAM libre      : ${memoriaLibre} MB
> RAM total      : ${memoriaTotal} MB
> CPU velocidad  : ${velocidadCPU} MHz
> CPU modelo     : ${modeloCPU}
\`\`\`
`;

    await sock.sendMessage(chatId, { text: textoEstado });
  }
};
