const estado = require('../estado');

async function sendFarewellMessage(update, sock) {
  if (!estado.welcomeEnabled) return;

  const { action, participants, id: jid } = update;
  if (action !== 'remove') return;

  // Obtener cantidad actual de miembros del grupo
  const metadata = await sock.groupMetadata(jid);
  const cantidad = metadata.participants.length;

  for (const participante of participants) {
    const mensaje = `-1 WACHITURRO 🇦🇷🥵\nNOS QUEDAN ${cantidad} WACHOS 🇦🇷`;
    await sock.sendMessage(jid, {
      text: mensaje,
      mentions: [participante]
    });
  }
}

module.exports = { sendFarewellMessage };