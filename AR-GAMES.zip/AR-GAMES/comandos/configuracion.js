const estado = require('../estado');

// Obtener el modo seguro actual
function obtenerModoSeguro() {
  return {
    activo: estado.modoSeguro,
    autorizado: '+573188774061@s.whatsapp.net' // Reemplaza con tu número en formato correcto si es distinto
  };
}

// Ejecutar comandos de configuración
async function ejecutarConfiguracion(sock, m, texto, remitente, infoGrupo) {
  const comando = texto.toLowerCase().trim();

  const esAdmin = infoGrupo?.participants?.some(p => p.id === remitente && p.admin);
  if (!esAdmin) return;

  const chatId = m.key.remoteJid;

  if (comando === ',,adminon') {
    estado.adminEnabled = true;
    await sock.sendMessage(chatId, { text: '✅ Comandos de administrador ACTIVADOS.' });
  }

  if (comando === ',,adminoff') {
    estado.adminEnabled = false;
    await sock.sendMessage(chatId, { text: '❌ Comandos de administrador DESACTIVADOS.' });
  }

  if (comando === ',,banlinkon') {
    estado.banLinkEnabled = true;
    await sock.sendMessage(chatId, { text: '✅ Eliminación de enlaces ACTIVADA.' });
  }

  if (comando === ',,banlinkoff') {
    estado.banLinkEnabled = false;
    await sock.sendMessage(chatId, { text: '❌ Eliminación de enlaces DESACTIVADA.' });
  }

  if (comando === ',,welcomeon') {
    estado.welcomeEnabled = true;
    await sock.sendMessage(chatId, { text: '✅ Mensaje de bienvenida ACTIVADO.' });
  }

  if (comando === ',,welcomeoff') {
    estado.welcomeEnabled = false;
    await sock.sendMessage(chatId, { text: '❌ Mensaje de bienvenida DESACTIVADO.' });
  }

  if (comando === ',,eldel_mc') {
    estado.modoSeguro = true;
    await sock.sendMessage(chatId, {
      text: '🛡️ MODO SEGURO ACTIVADO\nEL BOT SOLO RESPONDERÁ A @+573188774061',
      mentions: ['573188774061@s.whatsapp.net']
    });
  }
}

module.exports = {
  obtenerModoSeguro,
  ejecutarConfiguracion
};