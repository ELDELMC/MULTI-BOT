require('dotenv').config();
const axios = require('axios');

const API_KEYS = [
  process.env.GROQ_API_KEY_1,
  process.env.GROQ_API_KEY_2
];

let indiceClave = 0;
const modelo = 'llama3-70b-8192';

/**
 * Obtiene la siguiente clave válida en orden rotativo.
 */
function obtenerSiguienteClave() {
  const clave = API_KEYS[indiceClave];
  indiceClave = (indiceClave + 1) % API_KEYS.length;
  return clave;
}

/**
 * Genera una respuesta usando el modelo LLaMA3 de Groq.
 * Cambia de clave automáticamente si hay error.
 */
async function obtenerRespuestaIA(pregunta, nombreUsuario = 'jugador') {
  const prompt = `
Eres una administradora femenina muy amable llamada Luli que responde preguntas técnicas sobre Minecraft para el servidor argentino "🇦🇷 ARGENGAMES.LAT 🇦🇷".
Tu tono es cálido, amistoso y con jerga argentina, pero técnico si hace falta.

Usuario: ${nombreUsuario}
Pregunta: "${pregunta}"
`;

  for (let i = 0; i < API_KEYS.length; i++) {
    const apiKey = obtenerSiguienteClave();

    try {
      const response = await axios.post(
        'https://api.groq.com/openai/v1/chat/completions',
        {
          model: modelo,
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.7
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
          }
        }
      );

      return response.data.choices[0].message.content.trim();
    } catch (error) {
      console.error(`❌ Error con clave ${apiKey}:`, error.response?.data || error.message);
    }
  }

  return 'No pude responderte ahora mismo wachín 😢. Probá más tarde.';
}

module.exports = { obtenerRespuestaIA };