const { obtenerNombre } = require('./lib/utilidades');
const banYlinks = require('./comandos/banYlinks');
const adminHandler = require('./comandos/admin');
const welcomeHandler = require('./comandos/welcome');
const configuracionHandler = require('./comandos/configuracion');
const sistemaBot = require('./comandos/sistemaBot');
const { obtenerRespuestaIA } = require('./groq'); // Cambiado a Groq

module.exports.manejarMensajes = async (mensaje, sock) => {
  const m = mensaje.messages[0];
  if (!m.message || m.key.fromMe) return;

  const texto = m.message.conversation || m.message.extendedTextMessage?.text || '';
  const remitente = m.key.participant || m.key.remoteJid;
  const chatId = m.key.remoteJid;
  const esGrupo = chatId.endsWith('@g.us');

  let infoGrupo = {};
  if (esGrupo) {
    try {
      infoGrupo = await sock.groupMetadata(chatId);
    } catch (e) {
      console.error('Error obteniendo metadata del grupo:', e.message);
    }
  }

  // Logs
  console.log(`[COMANDO] ${texto} de: ${remitente}`);

  // Modo seguro (si está activo, solo responde al autorizado)
  let modoSeguro = null;
  try {
    modoSeguro = await configuracionHandler.obtenerModoSeguro?.();
  } catch (e) {
    console.error('Error obteniendo modo seguro:', e.message);
  }

  if (modoSeguro?.activo && remitente !== modoSeguro.autorizado) {
    return;
  }

  // Ejecutar configuración (,,adminon, ,,welcomeoff, etc)
  if (typeof configuracionHandler.ejecutarConfiguracion === 'function') {
    await configuracionHandler.ejecutarConfiguracion(sock, m, texto, remitente, infoGrupo);
  }

  // Moderación de enlaces y baneos automáticos
  if (typeof banYlinks === 'function') {
    await banYlinks(sock, m, texto, remitente, infoGrupo);
  }

  // Comandos admin: ,,admin y ,,noadmin
  if (typeof adminHandler === 'function') {
    await adminHandler(sock, m, texto, remitente, infoGrupo);
  }

  // Sistema automático del bot (bienvenida/despedida)
  if (typeof sistemaBot === 'function') {
    await sistemaBot(sock, m, texto, remitente, infoGrupo);
  }

  // Respuesta de inteligencia artificial con Groq
  if (texto.startsWith(',,bot')) {
    const pregunta = texto.replace(',,bot', '').trim();
    const nombreUsuario = await obtenerNombre(sock, remitente);
    const respuesta = await obtenerRespuestaIA(pregunta, nombreUsuario);

    await sock.sendMessage(chatId, { text: respuesta }, { quoted: m });
  }
};